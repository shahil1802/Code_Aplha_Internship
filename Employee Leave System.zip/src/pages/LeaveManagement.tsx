import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Layout } from '@/components/Layout';
import { Dashboard } from '@/components/Dashboard';
import { ApplyLeave } from '@/components/ApplyLeave';
import { LeaveHistory } from '@/components/LeaveHistory';
import { ManageApplications } from '@/components/ManageApplications';

export const LeaveManagement: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'apply':
        return <ApplyLeave />;
      case 'history':
        return <LeaveHistory />;
      case 'manage':
        return user?.role === 'admin' ? <ManageApplications /> : <Dashboard />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </Layout>
  );
};