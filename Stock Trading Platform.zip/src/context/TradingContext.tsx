import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Portfolio, Transaction, MarketData, TradingContextType } from '@/types/trading';
import { StockManager } from '@/classes/StockManager';
import { PortfolioManager } from '@/classes/PortfolioManager';
import { TradingEngine } from '@/classes/TradingEngine';

const TradingContext = createContext<TradingContextType | undefined>(undefined);

// Mock users data
const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Trader',
    email: 'john@trading.com',
    balance: 100000,
    createdAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '2',
    name: 'Sarah Investor',
    email: 'sarah@trading.com',
    balance: 50000,
    createdAt: '2024-01-01T00:00:00Z'
  }
];

export const TradingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  
  const [stockManager] = useState(new StockManager());
  const [portfolioManager, setPortfolioManager] = useState<PortfolioManager | null>(null);
  const [tradingEngine, setTradingEngine] = useState<TradingEngine | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('tradingUser');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      initializeUserSessions(parsedUser);
    }

    // Initialize market data
    setMarketData(stockManager.getMarketData());

    // Set up market data updates
    const interval = setInterval(() => {
      setMarketData(stockManager.getMarketData());
    }, 5000);

    return () => clearInterval(interval);
  }, [stockManager]);

  const initializeUserSessions = useCallback((userData: User) => {
    const portfolioMgr = new PortfolioManager(userData.id);
    const tradingEng = new TradingEngine(userData);
    
    setPortfolioManager(portfolioMgr);
    setTradingEngine(tradingEng);
    setTransactions(portfolioMgr.getTransactions());
    
    // Update portfolio with current market prices
    if (marketData) {
      portfolioMgr.updatePortfolioValues(marketData.stocks);
      setPortfolio(portfolioMgr.getPortfolio());
    }
  }, [marketData]);

  // Update portfolio values when market data changes
  useEffect(() => {
    if (portfolioManager && marketData) {
      portfolioManager.updatePortfolioValues(marketData.stocks);
      setPortfolio(portfolioManager.getPortfolio());
    }
  }, [marketData, portfolioManager]);

  const login = (email: string): boolean => {
    const foundUser = mockUsers.find(u => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('tradingUser', JSON.stringify(foundUser));
      initializeUserSessions(foundUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setPortfolio(null);
    setTransactions([]);
    setPortfolioManager(null);
    setTradingEngine(null);
    localStorage.removeItem('tradingUser');
  };

  const buyStock = (symbol: string, quantity: number, price: number): boolean => {
    if (!tradingEngine || !portfolioManager) return false;

    const result = tradingEngine.executeBuyOrder(symbol, quantity, price);
    if (result.success && result.transaction) {
      portfolioManager.addTransaction(result.transaction);
      setTransactions(portfolioManager.getTransactions());
      setPortfolio(portfolioManager.getPortfolio());
      setUser(tradingEngine.getUser());
      return true;
    }
    return false;
  };

  const sellStock = (symbol: string, quantity: number, price: number): boolean => {
    if (!tradingEngine || !portfolioManager) return false;

    if (!portfolioManager.canSell(symbol, quantity)) {
      return false;
    }

    const result = tradingEngine.executeSellOrder(symbol, quantity, price);
    if (result.success && result.transaction) {
      portfolioManager.addTransaction(result.transaction);
      setTransactions(portfolioManager.getTransactions());
      setPortfolio(portfolioManager.getPortfolio());
      setUser(tradingEngine.getUser());
      return true;
    }
    return false;
  };

  const updateBalance = (amount: number) => {
    if (tradingEngine) {
      tradingEngine.addFunds(amount);
      setUser(tradingEngine.getUser());
    }
  };

  const refreshMarketData = () => {
    setMarketData(stockManager.getMarketData());
  };

  return (
    <TradingContext.Provider value={{
      user,
      portfolio,
      transactions,
      marketData,
      login,
      logout,
      buyStock,
      sellStock,
      updateBalance,
      refreshMarketData
    }}>
      {children}
    </TradingContext.Provider>
  );
};

export const useTrading = () => {
  const context = useContext(TradingContext);
  if (context === undefined) {
    throw new Error('useTrading must be used within a TradingProvider');
  }
  return context;
};