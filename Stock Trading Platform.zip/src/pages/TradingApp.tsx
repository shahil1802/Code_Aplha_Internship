import React, { useState } from 'react';
import { TradingLayout } from '@/components/trading/TradingLayout';
import { MarketData } from '@/components/trading/MarketData';
import { TradingPanel } from '@/components/trading/TradingPanel';
import { Portfolio } from '@/components/trading/Portfolio';
import { TransactionHistory } from '@/components/trading/TransactionHistory';
import { Stock } from '@/types/trading';

export const TradingApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState('market');
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);

  const renderContent = () => {
    switch (activeTab) {
      case 'market':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="lg:col-span-1">
              <MarketData onSelectStock={setSelectedStock} />
            </div>
            <div className="lg:col-span-1">
              <TradingPanel selectedStock={selectedStock} />
            </div>
          </div>
        );
      case 'portfolio':
        return <Portfolio />;
      case 'transactions':
        return <TransactionHistory />;
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="lg:col-span-1">
              <MarketData onSelectStock={setSelectedStock} />
            </div>
            <div className="lg:col-span-1">
              <TradingPanel selectedStock={selectedStock} />
            </div>
          </div>
        );
    }
  };

  return (
    <TradingLayout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </TradingLayout>
  );
};