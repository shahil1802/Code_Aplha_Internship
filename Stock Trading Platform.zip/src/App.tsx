import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TradingProvider, useTrading } from '@/context/TradingContext';
import { TradingLoginForm } from '@/components/trading/LoginForm';
import { TradingApp } from '@/pages/TradingApp';

const queryClient = new QueryClient();

const AppContent = () => {
  const { user } = useTrading();
  
  return (
    <TooltipProvider>
      <Toaster />
      {user ? <TradingApp /> : <TradingLoginForm />}
    </TooltipProvider>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TradingProvider>
      <AppContent />
    </TradingProvider>
  </QueryClientProvider>
);

export default App;
