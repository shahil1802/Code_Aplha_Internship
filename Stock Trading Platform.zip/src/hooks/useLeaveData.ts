import { useState, useEffect } from 'react';
import { LeaveApplication } from '@/types';

export const useLeaveData = () => {
  const [leaveApplications, setLeaveApplications] = useState<LeaveApplication[]>([]);

  useEffect(() => {
    const savedApplications = localStorage.getItem('leaveApplications');
    if (savedApplications) {
      setLeaveApplications(JSON.parse(savedApplications));
    } else {
      // Initialize with some mock data
      const mockApplications: LeaveApplication[] = [
        {
          id: '1',
          employeeId: '1',
          employeeName: 'John Doe',
          startDate: '2024-09-01',
          endDate: '2024-09-03',
          leaveType: 'vacation',
          reason: 'Family vacation',
          status: 'approved',
          appliedDate: '2024-08-15',
          reviewedBy: 'Admin User',
          reviewDate: '2024-08-16',
          duration: 3
        },
        {
          id: '2',
          employeeId: '2',
          employeeName: 'Jane Smith',
          startDate: '2024-09-10',
          endDate: '2024-09-12',
          leaveType: 'sick',
          reason: 'Medical appointment',
          status: 'pending',
          appliedDate: '2024-08-20',
          duration: 3
        }
      ];
      setLeaveApplications(mockApplications);
      localStorage.setItem('leaveApplications', JSON.stringify(mockApplications));
    }
  }, []);

  const addLeaveApplication = (application: Omit<LeaveApplication, 'id' | 'appliedDate'>) => {
    const newApplication: LeaveApplication = {
      ...application,
      id: Date.now().toString(),
      appliedDate: new Date().toISOString().split('T')[0]
    };
    
    const updatedApplications = [...leaveApplications, newApplication];
    setLeaveApplications(updatedApplications);
    localStorage.setItem('leaveApplications', JSON.stringify(updatedApplications));
  };

  const updateLeaveApplication = (id: string, updates: Partial<LeaveApplication>) => {
    const updatedApplications = leaveApplications.map(app =>
      app.id === id ? { ...app, ...updates } : app
    );
    setLeaveApplications(updatedApplications);
    localStorage.setItem('leaveApplications', JSON.stringify(updatedApplications));
  };

  return {
    leaveApplications,
    addLeaveApplication,
    updateLeaveApplication
  };
};