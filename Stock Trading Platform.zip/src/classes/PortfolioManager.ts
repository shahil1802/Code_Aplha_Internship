import { Portfolio, PortfolioHolding, Transaction, Stock } from '@/types/trading';

export class PortfolioManager {
  private portfolio: Portfolio;
  private transactions: Transaction[];

  constructor(userId: string) {
    this.portfolio = {
      userId,
      holdings: [],
      totalValue: 0,
      totalGainLoss: 0,
      totalGainLossPercent: 0
    };
    this.transactions = [];
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    const savedPortfolio = localStorage.getItem(`portfolio_${this.portfolio.userId}`);
    const savedTransactions = localStorage.getItem(`transactions_${this.portfolio.userId}`);

    if (savedPortfolio) {
      this.portfolio = JSON.parse(savedPortfolio);
    }

    if (savedTransactions) {
      this.transactions = JSON.parse(savedTransactions);
    }
  }

  private saveToStorage(): void {
    localStorage.setItem(`portfolio_${this.portfolio.userId}`, JSON.stringify(this.portfolio));
    localStorage.setItem(`transactions_${this.portfolio.userId}`, JSON.stringify(this.transactions));
  }

  public addTransaction(transaction: Transaction): void {
    this.transactions.push(transaction);
    this.updateHoldings(transaction);
    this.saveToStorage();
  }

  private updateHoldings(transaction: Transaction): void {
    const existingHoldingIndex = this.portfolio.holdings.findIndex(
      h => h.symbol === transaction.symbol
    );

    if (transaction.type === 'buy') {
      if (existingHoldingIndex >= 0) {
        const holding = this.portfolio.holdings[existingHoldingIndex];
        const totalShares = holding.quantity + transaction.quantity;
        const totalCost = (holding.averagePrice * holding.quantity) + (transaction.price * transaction.quantity);
        
        holding.quantity = totalShares;
        holding.averagePrice = totalCost / totalShares;
      } else {
        this.portfolio.holdings.push({
          symbol: transaction.symbol,
          quantity: transaction.quantity,
          averagePrice: transaction.price,
          currentPrice: transaction.price,
          totalValue: transaction.total,
          gainLoss: 0,
          gainLossPercent: 0
        });
      }
    } else if (transaction.type === 'sell') {
      if (existingHoldingIndex >= 0) {
        const holding = this.portfolio.holdings[existingHoldingIndex];
        holding.quantity -= transaction.quantity;
        
        if (holding.quantity <= 0) {
          this.portfolio.holdings.splice(existingHoldingIndex, 1);
        }
      }
    }
  }

  public updatePortfolioValues(stocks: Stock[]): void {
    const stockMap = new Map(stocks.map(stock => [stock.symbol, stock]));
    let totalValue = 0;
    let totalCost = 0;

    this.portfolio.holdings.forEach(holding => {
      const currentStock = stockMap.get(holding.symbol);
      if (currentStock) {
        holding.currentPrice = currentStock.price;
        holding.totalValue = holding.quantity * currentStock.price;
        holding.gainLoss = holding.totalValue - (holding.quantity * holding.averagePrice);
        holding.gainLossPercent = ((currentStock.price - holding.averagePrice) / holding.averagePrice) * 100;
        
        totalValue += holding.totalValue;
        totalCost += holding.quantity * holding.averagePrice;
      }
    });

    this.portfolio.totalValue = totalValue;
    this.portfolio.totalGainLoss = totalValue - totalCost;
    this.portfolio.totalGainLossPercent = totalCost > 0 ? (this.portfolio.totalGainLoss / totalCost) * 100 : 0;
    
    this.saveToStorage();
  }

  public getPortfolio(): Portfolio {
    return this.portfolio;
  }

  public getTransactions(): Transaction[] {
    return this.transactions.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  public getHolding(symbol: string): PortfolioHolding | undefined {
    return this.portfolio.holdings.find(h => h.symbol === symbol);
  }

  public canSell(symbol: string, quantity: number): boolean {
    const holding = this.getHolding(symbol);
    return holding ? holding.quantity >= quantity : false;
  }

  public getPortfolioValue(): number {
    return this.portfolio.totalValue;
  }

  public getTotalGainLoss(): { amount: number; percent: number } {
    return {
      amount: this.portfolio.totalGainLoss,
      percent: this.portfolio.totalGainLossPercent
    };
  }
}