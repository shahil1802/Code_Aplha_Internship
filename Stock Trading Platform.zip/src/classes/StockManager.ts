import { Stock, MarketData } from '@/types/trading';

export class StockManager {
  private stocks: Map<string, Stock> = new Map();
  private marketData: MarketData;

  constructor() {
    this.initializeStocks();
    this.marketData = {
      stocks: Array.from(this.stocks.values()),
      lastUpdated: new Date().toISOString()
    };
    this.startPriceSimulation();
  }

  private initializeStocks(): void {
    const initialStocks: Stock[] = [
      {
        symbol: 'AAPL',
        name: 'Apple Inc.',
        price: 175.43,
        previousClose: 173.50,
        change: 1.93,
        changePercent: 1.11,
        volume: 52840000,
        marketCap: 2750000000000,
        sector: 'Technology'
      },
      {
        symbol: 'GOOGL',
        name: 'Alphabet Inc.',
        price: 138.21,
        previousClose: 140.05,
        change: -1.84,
        changePercent: -1.31,
        volume: 28450000,
        marketCap: 1720000000000,
        sector: 'Technology'
      },
      {
        symbol: 'MSFT',
        name: 'Microsoft Corporation',
        price: 378.85,
        previousClose: 376.30,
        change: 2.55,
        changePercent: 0.68,
        volume: 22180000,
        marketCap: 2810000000000,
        sector: 'Technology'
      },
      {
        symbol: 'TSLA',
        name: 'Tesla Inc.',
        price: 208.50,
        previousClose: 215.99,
        change: -7.49,
        changePercent: -3.47,
        volume: 78920000,
        marketCap: 660000000000,
        sector: 'Automotive'
      },
      {
        symbol: 'AMZN',
        name: 'Amazon.com Inc.',
        price: 145.86,
        previousClose: 147.20,
        change: -1.34,
        changePercent: -0.91,
        volume: 35670000,
        marketCap: 1520000000000,
        sector: 'E-commerce'
      },
      {
        symbol: 'NVDA',
        name: 'NVIDIA Corporation',
        price: 875.28,
        previousClose: 870.39,
        change: 4.89,
        changePercent: 0.56,
        volume: 45230000,
        marketCap: 2160000000000,
        sector: 'Technology'
      },
      {
        symbol: 'META',
        name: 'Meta Platforms Inc.',
        price: 325.60,
        previousClose: 328.45,
        change: -2.85,
        changePercent: -0.87,
        volume: 18950000,
        marketCap: 820000000000,
        sector: 'Technology'
      },
      {
        symbol: 'JPM',
        name: 'JPMorgan Chase & Co.',
        price: 165.42,
        previousClose: 163.80,
        change: 1.62,
        changePercent: 0.99,
        volume: 12340000,
        marketCap: 485000000000,
        sector: 'Financial'
      }
    ];

    initialStocks.forEach(stock => {
      this.stocks.set(stock.symbol, stock);
    });
  }

  private startPriceSimulation(): void {
    setInterval(() => {
      this.simulatePriceChanges();
    }, 5000); // Update every 5 seconds
  }

  private simulatePriceChanges(): void {
    this.stocks.forEach((stock, symbol) => {
      // Generate random price change (-2% to +2%)
      const changePercent = (Math.random() - 0.5) * 4;
      const changeAmount = stock.price * (changePercent / 100);
      const newPrice = Math.max(0.01, stock.price + changeAmount);
      
      const updatedStock: Stock = {
        ...stock,
        previousClose: stock.price,
        price: parseFloat(newPrice.toFixed(2)),
        change: parseFloat(changeAmount.toFixed(2)),
        changePercent: parseFloat(changePercent.toFixed(2)),
        volume: stock.volume + Math.floor(Math.random() * 10000)
      };

      this.stocks.set(symbol, updatedStock);
    });

    this.marketData = {
      stocks: Array.from(this.stocks.values()),
      lastUpdated: new Date().toISOString()
    };
  }

  public getStock(symbol: string): Stock | undefined {
    return this.stocks.get(symbol);
  }

  public getAllStocks(): Stock[] {
    return Array.from(this.stocks.values());
  }

  public getMarketData(): MarketData {
    return this.marketData;
  }

  public searchStocks(query: string): Stock[] {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.stocks.values()).filter(stock =>
      stock.symbol.toLowerCase().includes(lowerQuery) ||
      stock.name.toLowerCase().includes(lowerQuery)
    );
  }
}