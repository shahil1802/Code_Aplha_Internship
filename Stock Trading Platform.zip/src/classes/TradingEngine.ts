import { User, Transaction } from '@/types/trading';

export class TradingEngine {
  private user: User;

  constructor(user: User) {
    this.user = user;
  }

  public executeBuyOrder(symbol: string, quantity: number, price: number): { success: boolean; transaction?: Transaction; error?: string } {
    const total = quantity * price;
    const fee = this.calculateFee(total);
    const totalCost = total + fee;

    if (this.user.balance < totalCost) {
      return {
        success: false,
        error: `Insufficient funds. Required: $${totalCost.toFixed(2)}, Available: $${this.user.balance.toFixed(2)}`
      };
    }

    if (quantity <= 0) {
      return {
        success: false,
        error: 'Quantity must be greater than 0'
      };
    }

    // Execute the trade
    this.user.balance -= totalCost;
    this.saveUserToStorage();

    const transaction: Transaction = {
      id: this.generateTransactionId(),
      userId: this.user.id,
      symbol,
      type: 'buy',
      quantity,
      price,
      total: totalCost,
      timestamp: new Date().toISOString(),
      status: 'completed'
    };

    return {
      success: true,
      transaction
    };
  }

  public executeSellOrder(symbol: string, quantity: number, price: number): { success: boolean; transaction?: Transaction; error?: string } {
    if (quantity <= 0) {
      return {
        success: false,
        error: 'Quantity must be greater than 0'
      };
    }

    const total = quantity * price;
    const fee = this.calculateFee(total);
    const netAmount = total - fee;

    // Add proceeds to balance
    this.user.balance += netAmount;
    this.saveUserToStorage();

    const transaction: Transaction = {
      id: this.generateTransactionId(),
      userId: this.user.id,
      symbol,
      type: 'sell',
      quantity,
      price,
      total: netAmount,
      timestamp: new Date().toISOString(),
      status: 'completed'
    };

    return {
      success: true,
      transaction
    };
  }

  private calculateFee(amount: number): number {
    // Simple flat fee of $1 per transaction
    return 1.00;
  }

  private generateTransactionId(): string {
    return `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private saveUserToStorage(): void {
    localStorage.setItem('tradingUser', JSON.stringify(this.user));
  }

  public getUser(): User {
    return this.user;
  }

  public updateBalance(newBalance: number): void {
    this.user.balance = newBalance;
    this.saveUserToStorage();
  }

  public addFunds(amount: number): void {
    this.user.balance += amount;
    this.saveUserToStorage();
  }
}