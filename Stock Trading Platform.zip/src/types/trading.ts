export interface Stock {
  symbol: string;
  name: string;
  price: number;
  previousClose: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  sector: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  balance: number;
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  symbol: string;
  type: 'buy' | 'sell';
  quantity: number;
  price: number;
  total: number;
  timestamp: string;
  status: 'completed' | 'pending' | 'cancelled';
}

export interface Portfolio {
  userId: string;
  holdings: PortfolioHolding[];
  totalValue: number;
  totalGainLoss: number;
  totalGainLossPercent: number;
}

export interface PortfolioHolding {
  symbol: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  totalValue: number;
  gainLoss: number;
  gainLossPercent: number;
}

export interface MarketData {
  stocks: Stock[];
  lastUpdated: string;
}

export interface TradingContextType {
  user: User | null;
  portfolio: Portfolio | null;
  transactions: Transaction[];
  marketData: MarketData | null;
  login: (email: string) => boolean;
  logout: () => void;
  buyStock: (symbol: string, quantity: number, price: number) => boolean;
  sellStock: (symbol: string, quantity: number, price: number) => boolean;
  updateBalance: (amount: number) => void;
  refreshMarketData: () => void;
}