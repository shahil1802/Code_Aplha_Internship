import React, { useState } from 'react';
import { useLeaveData } from '@/hooks/useLeaveData';
import { useAuth } from '@/context/AuthContext';
import { LeaveApplication } from '@/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Users, Search, Filter, AlertCircle, CheckCircle, XCircle, Eye } from 'lucide-react';
import { toast } from 'sonner';

export const ManageApplications: React.FC = () => {
  const { user } = useAuth();
  const { leaveApplications, updateLeaveApplication } = useLeaveData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedApplication, setSelectedApplication] = useState<LeaveApplication | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);

  const filteredApplications = leaveApplications.filter(app => {
    const matchesSearch = app.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.leaveType.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const sortedApplications = filteredApplications.sort((a, b) => {
    if (a.status === 'pending' && b.status !== 'pending') return -1;
    if (a.status !== 'pending' && b.status === 'pending') return 1;
    return new Date(b.appliedDate).getTime() - new Date(a.appliedDate).getTime();
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleReview = (application: LeaveApplication) => {
    setSelectedApplication(application);
    setReviewNotes(application.reviewNotes || '');
    setIsReviewDialogOpen(true);
  };

  const handleApprove = () => {
    if (selectedApplication) {
      updateLeaveApplication(selectedApplication.id, {
        status: 'approved',
        reviewedBy: user?.name,
        reviewDate: new Date().toISOString().split('T')[0],
        reviewNotes
      });
      toast.success(`Leave application approved for ${selectedApplication.employeeName}`);
      setIsReviewDialogOpen(false);
      setSelectedApplication(null);
      setReviewNotes('');
    }
  };

  const handleReject = () => {
    if (selectedApplication) {
      updateLeaveApplication(selectedApplication.id, {
        status: 'rejected',
        reviewedBy: user?.name,
        reviewDate: new Date().toISOString().split('T')[0],
        reviewNotes
      });
      toast.success(`Leave application rejected for ${selectedApplication.employeeName}`);
      setIsReviewDialogOpen(false);
      setSelectedApplication(null);
      setReviewNotes('');
    }
  };

  const pendingCount = leaveApplications.filter(app => app.status === 'pending').length;
  const approvedCount = leaveApplications.filter(app => app.status === 'approved').length;
  const rejectedCount = leaveApplications.filter(app => app.status === 'rejected').length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Manage Applications</h2>
        <p className="text-gray-600">Review and approve leave applications</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingCount}</div>
            <p className="text-xs text-muted-foreground">Applications</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedCount}</div>
            <p className="text-xs text-muted-foreground">Applications</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rejected</CardTitle>
            <XCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{rejectedCount}</div>
            <p className="text-xs text-muted-foreground">Applications</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5" />
            <span>All Leave Applications</span>
          </CardTitle>
          <CardDescription>
            Total Applications: {leaveApplications.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by employee name, reason, or type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          {sortedApplications.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No applications found</p>
              <p className="text-sm">Try adjusting your search filters</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Dates</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Applied</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedApplications.map((application) => (
                    <TableRow key={application.id}>
                      <TableCell className="font-medium">
                        {application.employeeName}
                      </TableCell>
                      <TableCell>
                        {application.leaveType.charAt(0).toUpperCase() + application.leaveType.slice(1)}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{formatDate(application.startDate)}</div>
                          <div className="text-gray-500">to {formatDate(application.endDate)}</div>
                        </div>
                      </TableCell>
                      <TableCell>{application.duration} days</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(application.status)}>
                          {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{formatDate(application.appliedDate)}</TableCell>
                      <TableCell>
                        <Dialog open={isReviewDialogOpen && selectedApplication?.id === application.id} onOpenChange={setIsReviewDialogOpen}>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleReview(application)}
                              className="flex items-center space-x-1"
                            >
                              <Eye className="h-4 w-4" />
                              <span>Review</span>
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-[500px]">
                            <DialogHeader>
                              <DialogTitle>Review Leave Application</DialogTitle>
                              <DialogDescription>
                                Review and approve or reject this leave application.
                              </DialogDescription>
                            </DialogHeader>
                            {selectedApplication && (
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Employee</Label>
                                    <p className="text-sm">{selectedApplication.employeeName}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Leave Type</Label>
                                    <p className="text-sm">{selectedApplication.leaveType.charAt(0).toUpperCase() + selectedApplication.leaveType.slice(1)}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Start Date</Label>
                                    <p className="text-sm">{formatDate(selectedApplication.startDate)}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">End Date</Label>
                                    <p className="text-sm">{formatDate(selectedApplication.endDate)}</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Duration</Label>
                                    <p className="text-sm">{selectedApplication.duration} days</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm font-medium text-gray-700">Applied Date</Label>
                                    <p className="text-sm">{formatDate(selectedApplication.appliedDate)}</p>
                                  </div>
                                </div>
                                <div>
                                  <Label className="text-sm font-medium text-gray-700">Reason</Label>
                                  <p className="text-sm p-3 bg-gray-50 rounded-md">{selectedApplication.reason}</p>
                                </div>
                                <div>
                                  <Label htmlFor="reviewNotes">Review Notes (Optional)</Label>
                                  <Textarea
                                    id="reviewNotes"
                                    placeholder="Add any notes for this review..."
                                    value={reviewNotes}
                                    onChange={(e) => setReviewNotes(e.target.value)}
                                    rows={3}
                                  />
                                </div>
                              </div>
                            )}
                            <DialogFooter className="space-x-2">
                              <Button
                                variant="outline"
                                onClick={() => setIsReviewDialogOpen(false)}
                              >
                                Cancel
                              </Button>
                              {selectedApplication?.status === 'pending' && (
                                <>
                                  <Button
                                    variant="destructive"
                                    onClick={handleReject}
                                    className="flex items-center space-x-1"
                                  >
                                    <XCircle className="h-4 w-4" />
                                    <span>Reject</span>
                                  </Button>
                                  <Button
                                    onClick={handleApprove}
                                    className="flex items-center space-x-1"
                                  >
                                    <CheckCircle className="h-4 w-4" />
                                    <span>Approve</span>
                                  </Button>
                                </>
                              )}
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};