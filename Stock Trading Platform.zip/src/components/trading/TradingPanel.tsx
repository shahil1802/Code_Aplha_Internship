import React, { useState } from 'react';
import { useTrading } from '@/context/TradingContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ShoppingCart, TrendingDown, AlertCircle, DollarSign } from 'lucide-react';
import { Stock } from '@/types/trading';
import { toast } from 'sonner';

interface TradingPanelProps {
  selectedStock: Stock | null;
}

export const TradingPanel: React.FC<TradingPanelProps> = ({ selectedStock }) => {
  const { user, portfolio, buyStock, sellStock } = useTrading();
  const [quantity, setQuantity] = useState('');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const holdings = portfolio?.holdings.find(h => h.symbol === selectedStock?.symbol);
  const availableShares = holdings?.quantity || 0;

  const calculateTotal = (type: 'buy' | 'sell'): number => {
    if (!selectedStock || !quantity) return 0;
    const shares = parseInt(quantity);
    const total = shares * selectedStock.price;
    const fee = 1.00; // Flat fee
    return type === 'buy' ? total + fee : total - fee;
  };

  const validateOrder = (type: 'buy' | 'sell'): boolean => {
    const newErrors: Record<string, string> = {};

    if (!selectedStock) {
      newErrors.stock = 'Please select a stock';
    }

    if (!quantity || parseInt(quantity) <= 0) {
      newErrors.quantity = 'Please enter a valid quantity';
    }

    const shares = parseInt(quantity);
    const total = calculateTotal(type);

    if (type === 'buy') {
      if (user && total > user.balance) {
        newErrors.balance = `Insufficient funds. Required: $${total.toFixed(2)}, Available: $${user.balance.toFixed(2)}`;
      }
    } else if (type === 'sell') {
      if (shares > availableShares) {
        newErrors.shares = `Insufficient shares. Available: ${availableShares}, Requested: ${shares}`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleBuy = () => {
    if (!selectedStock || !validateOrder('buy')) return;

    const shares = parseInt(quantity);
    const success = buyStock(selectedStock.symbol, shares, selectedStock.price);

    if (success) {
      toast.success(`Successfully bought ${shares} shares of ${selectedStock.symbol}`);
      setQuantity('');
      setErrors({});
    } else {
      toast.error('Failed to execute buy order');
    }
  };

  const handleSell = () => {
    if (!selectedStock || !validateOrder('sell')) return;

    const shares = parseInt(quantity);
    const success = sellStock(selectedStock.symbol, shares, selectedStock.price);

    if (success) {
      toast.success(`Successfully sold ${shares} shares of ${selectedStock.symbol}`);
      setQuantity('');
      setErrors({});
    } else {
      toast.error('Failed to execute sell order');
    }
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  if (!selectedStock) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ShoppingCart className="h-5 w-5" />
            <span>Trading Panel</span>
          </CardTitle>
          <CardDescription>Select a stock to start trading</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>Click "Trade" on any stock in the market data to get started</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShoppingCart className="h-5 w-5" />
            <span>Trading Panel</span>
          </div>
          <Badge variant="outline" className="text-sm">
            {selectedStock.symbol}
          </Badge>
        </CardTitle>
        <CardDescription>
          {selectedStock.name} • {formatCurrency(selectedStock.price)}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Stock Info */}
          <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <div className="text-sm text-gray-600">Current Price</div>
              <div className="text-lg font-bold">{formatCurrency(selectedStock.price)}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Change</div>
              <div className={`text-lg font-bold ${selectedStock.changePercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatCurrency(selectedStock.change)} ({selectedStock.changePercent.toFixed(2)}%)
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Your Holdings</div>
              <div className="text-lg font-bold">{availableShares} shares</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Available Balance</div>
              <div className="text-lg font-bold">{formatCurrency(user?.balance || 0)}</div>
            </div>
          </div>

          {/* Trading Form */}
          <Tabs value="market" className="w-full">
            <TabsList className="grid w-full grid-cols-1">
              <TabsTrigger value="market">Market Order</TabsTrigger>
            </TabsList>
            <TabsContent value="market" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="Enter number of shares"
                />
                {errors.quantity && (
                  <p className="text-sm text-red-600">{errors.quantity}</p>
                )}
              </div>

              {quantity && parseInt(quantity) > 0 && (
                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Shares:</span>
                    <span>{quantity}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Price per share:</span>
                    <span>{formatCurrency(selectedStock.price)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Trading fee:</span>
                    <span>$1.00</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium">
                    <span>Buy Total:</span>
                    <span>{formatCurrency(calculateTotal('buy'))}</span>
                  </div>
                  <div className="flex justify-between font-medium">
                    <span>Sell Total:</span>
                    <span>{formatCurrency(calculateTotal('sell'))}</span>
                  </div>
                </div>
              )}

              {Object.keys(errors).length > 0 && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {Object.values(errors).map((error, index) => (
                      <div key={index}>{error}</div>
                    ))}
                  </AlertDescription>
                </Alert>
              )}

              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={handleBuy}
                  className="w-full bg-green-600 hover:bg-green-700"
                  disabled={!quantity || parseInt(quantity) <= 0}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Buy
                </Button>
                <Button
                  onClick={handleSell}
                  variant="outline"
                  className="w-full border-red-600 text-red-600 hover:bg-red-50"
                  disabled={!quantity || parseInt(quantity) <= 0 || availableShares === 0}
                >
                  <TrendingDown className="h-4 w-4 mr-2" />
                  Sell
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
};