import React from 'react';
import { useTrading } from '@/context/TradingContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TrendingUp, TrendingDown, Wallet, DollarSign, PieChart, AlertCircle } from 'lucide-react';

export const Portfolio: React.FC = () => {
  const { user, portfolio, marketData } = useTrading();

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  const formatPercent = (value: number): string => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  const getTrendColor = (value: number) => {
    if (value > 0) return 'text-green-600';
    if (value < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  const getTrendIcon = (value: number) => {
    if (value > 0) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (value < 0) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return null;
  };

  const totalPortfolioValue = (portfolio?.totalValue || 0) + (user?.balance || 0);

  if (!portfolio || portfolio.holdings.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <PieChart className="h-5 w-5" />
            <span>Portfolio</span>
          </CardTitle>
          <CardDescription>Your investment portfolio</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <PieChart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>No holdings in your portfolio</p>
            <p className="text-sm">Start by buying some stocks to build your portfolio</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Portfolio Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Portfolio Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalPortfolioValue)}</div>
            <p className="text-xs text-muted-foreground">Cash + Holdings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Holdings Value</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(portfolio.totalValue)}</div>
            <p className="text-xs text-muted-foreground">Market value</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cash Balance</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(user?.balance || 0)}</div>
            <p className="text-xs text-muted-foreground">Available to trade</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Gain/Loss</CardTitle>
            {getTrendIcon(portfolio.totalGainLoss)}
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getTrendColor(portfolio.totalGainLoss)}`}>
              {formatCurrency(portfolio.totalGainLoss)}
            </div>
            <p className={`text-xs ${getTrendColor(portfolio.totalGainLossPercent)}`}>
              {formatPercent(portfolio.totalGainLossPercent)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Holdings Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <PieChart className="h-5 w-5" />
            <span>Holdings</span>
          </CardTitle>
          <CardDescription>Your current stock positions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Avg. Price</TableHead>
                  <TableHead>Current Price</TableHead>
                  <TableHead>Market Value</TableHead>
                  <TableHead>Gain/Loss</TableHead>
                  <TableHead>% Change</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {portfolio.holdings.map((holding) => (
                  <TableRow key={holding.symbol}>
                    <TableCell className="font-medium">
                      <div className="flex items-center space-x-2">
                        {getTrendIcon(holding.gainLossPercent)}
                        <span>{holding.symbol}</span>
                      </div>
                    </TableCell>
                    <TableCell>{holding.quantity.toLocaleString()}</TableCell>
                    <TableCell>{formatCurrency(holding.averagePrice)}</TableCell>
                    <TableCell>{formatCurrency(holding.currentPrice)}</TableCell>
                    <TableCell className="font-medium">
                      {formatCurrency(holding.totalValue)}
                    </TableCell>
                    <TableCell className={getTrendColor(holding.gainLoss)}>
                      {formatCurrency(holding.gainLoss)}
                    </TableCell>
                    <TableCell className={getTrendColor(holding.gainLossPercent)}>
                      {formatPercent(holding.gainLossPercent)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Portfolio Allocation */}
      <Card>
        <CardHeader>
          <CardTitle>Portfolio Allocation</CardTitle>
          <CardDescription>Distribution of your investments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {portfolio.holdings.map((holding) => {
              const percentage = (holding.totalValue / portfolio.totalValue) * 100;
              return (
                <div key={holding.symbol} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{holding.symbol}</span>
                    <span className="text-sm text-gray-600">
                      {percentage.toFixed(1)}% • {formatCurrency(holding.totalValue)}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};