import React, { useState } from 'react';
import { useTrading } from '@/context/TradingContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, TrendingUp, TrendingDown, Minus, RefreshCw } from 'lucide-react';
import { Stock } from '@/types/trading';

interface MarketDataProps {
  onSelectStock: (stock: Stock) => void;
}

export const MarketData: React.FC<MarketDataProps> = ({ onSelectStock }) => {
  const { marketData, refreshMarketData } = useTrading();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStocks = marketData?.stocks.filter(stock =>
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stock.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  const formatNumber = (value: number): string => {
    if (value >= 1e9) {
      return `${(value / 1e9).toFixed(1)}B`;
    }
    if (value >= 1e6) {
      return `${(value / 1e6).toFixed(1)}M`;
    }
    if (value >= 1e3) {
      return `${(value / 1e3).toFixed(1)}K`;
    }
    return value.toLocaleString();
  };

  const getTrendIcon = (changePercent: number) => {
    if (changePercent > 0) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (changePercent < 0) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  const getTrendColor = (changePercent: number) => {
    if (changePercent > 0) return 'text-green-600';
    if (changePercent < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>Market Data</span>
            </CardTitle>
            <CardDescription>
              Live stock prices • Last updated: {marketData?.lastUpdated ? 
                new Date(marketData.lastUpdated).toLocaleTimeString() : 'Never'}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={refreshMarketData}
            className="flex items-center space-x-2"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search stocks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Market Overview Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-4">
              <div className="text-sm text-gray-600">Market Cap</div>
              <div className="text-2xl font-bold">
                ${formatNumber(filteredStocks.reduce((sum, stock) => sum + stock.marketCap, 0))}
              </div>
            </Card>
            <Card className="p-4">
              <div className="text-sm text-gray-600">Total Volume</div>
              <div className="text-2xl font-bold">
                {formatNumber(filteredStocks.reduce((sum, stock) => sum + stock.volume, 0))}
              </div>
            </Card>
            <Card className="p-4">
              <div className="text-sm text-gray-600">Gainers</div>
              <div className="text-2xl font-bold text-green-600">
                {filteredStocks.filter(s => s.changePercent > 0).length}
              </div>
            </Card>
            <Card className="p-4">
              <div className="text-sm text-gray-600">Losers</div>
              <div className="text-2xl font-bold text-red-600">
                {filteredStocks.filter(s => s.changePercent < 0).length}
              </div>
            </Card>
          </div>

          {/* Stock Table */}
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Change</TableHead>
                  <TableHead>Volume</TableHead>
                  <TableHead>Market Cap</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStocks.map((stock) => (
                  <TableRow key={stock.symbol} className="hover:bg-gray-50">
                    <TableCell className="font-medium">
                      <div className="flex items-center space-x-2">
                        {getTrendIcon(stock.changePercent)}
                        <span>{stock.symbol}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{stock.name}</div>
                        <div className="text-sm text-gray-500">{stock.sector}</div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {formatCurrency(stock.price)}
                    </TableCell>
                    <TableCell>
                      <div className={`flex items-center space-x-1 ${getTrendColor(stock.changePercent)}`}>
                        <span>{formatCurrency(stock.change)}</span>
                        <span>({stock.changePercent.toFixed(2)}%)</span>
                      </div>
                    </TableCell>
                    <TableCell>{formatNumber(stock.volume)}</TableCell>
                    <TableCell>{formatNumber(stock.marketCap)}</TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onSelectStock(stock)}
                      >
                        Trade
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};