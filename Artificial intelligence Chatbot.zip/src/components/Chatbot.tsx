import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Send, Bot, User, Loader2 } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const FAQ_RESPONSES = {
  greeting: [
    "Hello! How can I help you today?",
    "Hi there! What can I assist you with?",
    "Welcome! I'm here to help. What would you like to know?"
  ],
  help: [
    "I can help you with various topics including general questions, weather, time, calculations, and more. Just ask me anything!",
    "I'm here to assist you with information and answer your questions. What do you need help with?"
  ],
  weather: [
    "I don't have real-time weather data, but I recommend checking your local weather app or website for current conditions.",
    "For accurate weather information, please check a reliable weather service like Weather.com or your local weather app."
  ],
  time: [
    `The current time is ${new Date().toLocaleTimeString()}.`,
    `Right now it's ${new Date().toLocaleTimeString()}.`
  ],
  default: [
    "I understand you're asking about that topic. Could you provide more details so I can help you better?",
    "That's an interesting question! Can you tell me more about what specifically you'd like to know?",
    "I'm here to help! Could you rephrase your question or provide more context?",
    "I want to give you the best answer possible. Can you be more specific about what you're looking for?"
  ],
  goodbye: [
    "Goodbye! Feel free to come back anytime if you have more questions.",
    "See you later! I'm always here when you need help.",
    "Take care! Don't hesitate to ask if you need anything else."
  ],
  thanks: [
    "You're welcome! I'm glad I could help.",
    "Happy to help! Is there anything else you'd like to know?",
    "My pleasure! Feel free to ask me anything else."
  ]
};

const Chatbot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your AI assistant. How can I help you today?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeMessage = (text: string): string[] => {
    const lowerText = text.toLowerCase().trim();
    
    // Greeting patterns
    if (/^(hi|hello|hey|good morning|good afternoon|good evening)/.test(lowerText)) {
      return FAQ_RESPONSES.greeting;
    }
    
    // Help patterns
    if (/(help|assist|support|what can you do)/.test(lowerText)) {
      return FAQ_RESPONSES.help;
    }
    
    // Weather patterns
    if (/(weather|temperature|rain|sunny|cloudy)/.test(lowerText)) {
      return FAQ_RESPONSES.weather;
    }
    
    // Time patterns
    if (/(time|what time|current time|clock)/.test(lowerText)) {
      return FAQ_RESPONSES.time;
    }
    
    // Goodbye patterns
    if (/(bye|goodbye|see you|farewell|exit)/.test(lowerText)) {
      return FAQ_RESPONSES.goodbye;
    }
    
    // Thanks patterns
    if (/(thank|thanks|appreciate)/.test(lowerText)) {
      return FAQ_RESPONSES.thanks;
    }
    
    // Math calculations
    if (/[\d+\-*/().\s]+/.test(lowerText) && /[+\-*/]/.test(lowerText)) {
      try {
        // Simple math evaluation (safe for basic operations)
        const result = Function('"use strict"; return (' + lowerText.replace(/[^0-9+\-*/().\s]/g, '') + ')')();
        return [`The result is: ${result}`];
      } catch {
        return ["I can help with basic math calculations. Please use numbers and operators like +, -, *, /."];
      }
    }
    
    return FAQ_RESPONSES.default;
  };

  const generateBotResponse = (userMessage: string): string => {
    const responses = analyzeMessage(userMessage);
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateBotResponse(inputValue),
        sender: 'bot',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto h-[600px] flex flex-col">
      <CardHeader className="pb-4">
        <div className="flex items-center space-x-2">
          <Avatar>
            <AvatarFallback>
              <Bot className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold">AI Assistant</h3>
            <p className="text-sm text-muted-foreground">
              {isTyping ? 'Typing...' : 'Online'}
            </p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 px-4" ref={scrollAreaRef}>
          <div className="space-y-4 pb-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start space-x-2 ${
                  message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}
              >
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    {message.sender === 'user' ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                  </AvatarFallback>
                </Avatar>
                <div
                  className={`max-w-[80%] rounded-lg px-3 py-2 ${
                    message.sender === 'user'
                      ? 'bg-primary text-primary-foreground ml-auto'
                      : 'bg-muted'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex items-start space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-muted rounded-lg px-3 py-2">
                  <div className="flex items-center space-x-1">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">Typing...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        <div className="p-4 border-t">
          <div className="flex space-x-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1"
              disabled={isTyping}
            />
            <Button 
              onClick={handleSendMessage} 
              size="icon"
              disabled={!inputValue.trim() || isTyping}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Chatbot;