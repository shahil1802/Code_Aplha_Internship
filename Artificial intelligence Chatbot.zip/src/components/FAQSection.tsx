import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Clock, CloudRain, Calculator, HelpCircle, Heart } from 'lucide-react';

const FAQ_CATEGORIES = [
  {
    icon: MessageCircle,
    title: "Greetings",
    description: "Say hello and start a conversation",
    examples: ["Hello", "Hi there", "Good morning"]
  },
  {
    icon: HelpCircle,
    title: "Getting Help",
    description: "Ask for assistance and guidance",
    examples: ["Help me", "What can you do?", "I need support"]
  },
  {
    icon: Clock,
    title: "Time & Date",
    description: "Get current time information",
    examples: ["What time is it?", "Current time", "Show me the time"]
  },
  {
    icon: CloudRain,
    title: "Weather",
    description: "Weather-related inquiries",
    examples: ["Weather today", "Is it raining?", "Temperature"]
  },
  {
    icon: Calculator,
    title: "Calculations",
    description: "Basic math operations",
    examples: ["2 + 2", "15 * 3", "100 / 4"]
  },
  {
    icon: Heart,
    title: "Gratitude",
    description: "Express thanks and appreciation",
    examples: ["Thank you", "Thanks a lot", "I appreciate it"]
  }
];

const FAQSection: React.FC = () => {
  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold mb-2">What I Can Help You With</h2>
        <p className="text-muted-foreground">
          Here are some examples of what you can ask me. Try typing any of these phrases!
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {FAQ_CATEGORIES.map((category, index) => {
          const IconComponent = category.icon;
          return (
            <Card key={index} className="h-full hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center space-x-2">
                  <IconComponent className="h-5 w-5 text-primary" />
                  <CardTitle className="text-lg">{category.title}</CardTitle>
                </div>
                <p className="text-sm text-muted-foreground">
                  {category.description}
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Try saying:</p>
                  <div className="flex flex-wrap gap-1">
                    {category.examples.map((example, exampleIndex) => (
                      <Badge 
                        key={exampleIndex} 
                        variant="secondary" 
                        className="text-xs"
                      >
                        "{example}"
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default FAQSection;