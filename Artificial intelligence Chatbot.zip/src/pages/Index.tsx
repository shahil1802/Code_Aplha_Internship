import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Chatbot from '@/components/Chatbot';
import FAQSection from '@/components/FAQSection';
import { Bot, MessageSquare, HelpCircle, Sparkles } from 'lucide-react';

export default function Index() {
  const [activeTab, setActiveTab] = useState("chat");

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Bot className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold">AI Chatbot Assistant</h1>
                <p className="text-sm text-muted-foreground">
                  Interactive AI-powered conversation
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="hidden sm:flex items-center space-x-1 text-sm text-muted-foreground">
                <Sparkles className="h-4 w-4" />
                <span>Powered by NLP</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-center mb-8">
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="chat" className="flex items-center space-x-2">
                <MessageSquare className="h-4 w-4" />
                <span>Chat</span>
              </TabsTrigger>
              <TabsTrigger value="faq" className="flex items-center space-x-2">
                <HelpCircle className="h-4 w-4" />
                <span>FAQ Guide</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="chat" className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-bold tracking-tight">
                Start a Conversation
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Ask me anything! I can help with general questions, calculations, 
                provide information, and engage in meaningful conversations.
              </p>
            </div>
            
            <div className="flex justify-center">
              <Chatbot />
            </div>
          </TabsContent>

          <TabsContent value="faq" className="space-y-6">
            <FAQSection />
          </TabsContent>
        </Tabs>
      </main>

      {/* Features Section */}
      <section className="bg-white/50 backdrop-blur-sm py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Intelligent Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Experience advanced AI capabilities with natural language processing and smart responses
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="text-center p-6">
              <CardContent className="space-y-4">
                <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto">
                  <MessageSquare className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="font-semibold">Natural Language Processing</h3>
                <p className="text-sm text-muted-foreground">
                  Advanced text analysis to understand your questions and provide relevant responses
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6">
              <CardContent className="space-y-4">
                <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto">
                  <Sparkles className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold">Smart Responses</h3>
                <p className="text-sm text-muted-foreground">
                  Context-aware answers based on pattern recognition and rule-based logic
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6">
              <CardContent className="space-y-4">
                <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mx-auto">
                  <Bot className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="font-semibold">Real-time Interaction</h3>
                <p className="text-sm text-muted-foreground">
                  Instant responses with typing indicators for a natural conversation experience
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm border-t py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Bot className="h-5 w-5 text-primary" />
            <span className="font-semibold">AI Chatbot Assistant</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Built with React, TypeScript, and modern web technologies
          </p>
        </div>
      </footer>
    </div>
  );
}